using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AI_Move : MonoBehaviour
{

    public float speed = 5f; // speed at which the object moves
    public float upDistance = 5f; // distance to move up
    public float rightDistance = 5f; // distance to move right
    public Vector3 targetPosition; // position to move towards
    public Vector3 targetPosition2; // position to move towards
    public Vector3 targetPosition3; // position to move towards

    public Vector3 targetPosition4; // position to move towards
    public Vector3 targetPosition5; // position to move towards
    public Vector3 targetPosition6;

    private bool reachedTargetPosition = false; // flag to indicate if the object has reached the target position
    private bool reachedTargetPosition2 = false;
    private bool reachedTargetPosition3 = false;
    private bool reachedTargetPosition4 = false; // flag to indicate if the object has reached the target position
    private bool reachedTargetPosition5 = false;
    private bool reachedTargetPosition6 = false;
    void Update()
    {
        if (!reachedTargetPosition)
        {
            // move the object up until it reaches the target position
            transform.position = Vector3.MoveTowards(transform.position, targetPosition, speed * Time.deltaTime);

            // check if the object has reached the target position
            if (transform.position == targetPosition)
            {
                reachedTargetPosition = true;
            }
        }
        else if(!reachedTargetPosition2)
        {
            // move the object to the right
            transform.position = Vector3.MoveTowards(transform.position, targetPosition2,  speed * Time.deltaTime);
            if (transform.position == targetPosition2)
            {
                reachedTargetPosition2 = true;
            }
        }
        else if(!reachedTargetPosition3)
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPosition3, speed * Time.deltaTime);
            if (transform.position == targetPosition3)
            {
                reachedTargetPosition3 = true;
            }
        }
        else if (!reachedTargetPosition4)
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPosition4, speed * Time.deltaTime);
            if (transform.position == targetPosition4)
            {
                reachedTargetPosition4 = true;
            }
        }
        else if (!reachedTargetPosition5)
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPosition5, speed * Time.deltaTime);
            if (transform.position == targetPosition5)
            {
                reachedTargetPosition5 = true;
            }
        }
        else if (!reachedTargetPosition6)
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPosition6, speed * Time.deltaTime);
            if (transform.position == targetPosition6)
            {
                reachedTargetPosition6 = true;
            }
        }
    }

    void Start()
    {
        // calculate the target position based on the initial position
        targetPosition = transform.position + new Vector3(0f, 16.5f, 0f);
        targetPosition2 = transform.position + new Vector3(2.3f, 16.5f, 0f);
        targetPosition3 = transform.position + new Vector3(2.3f, 13.9f, 0f);
        targetPosition4 = transform.position + new Vector3(26f, 13.9f, 0f);
        targetPosition5 = transform.position + new Vector3(26f, 16.7f, 0f);
        targetPosition6 = transform.position + new Vector3(28f, 16.7f, 0f);


    }

    //public float speed = 5f; // speed at which the object moves
    //public float upDistance = 2000f; // distance to move up
    //public float rightDistance = 5f; // distance to move right

    //private Vector3 targetPosition; // position to move towards
    //private Vector3 targetPosition2;
    //private Vector3 targetPosition3;
    //private Vector3 targetPosition4;
    //private Vector3 targetPosition5;
    //private Vector3 targetPosition6;

    //void Start()
    //{
    //    // calculate the target position based on the initial position
    //    targetPosition = transform.position + new Vector3(0f, 16.5f, 0f);
    //    targetPosition2 = transform.position + new Vector3(2f, 0f, 0f);
    //    targetPosition3 = transform.position + new Vector3(0f, 16.5f, 0f);
    //    targetPosition4 = transform.position + new Vector3(0f, 16.5f, 0f);
    //    targetPosition5 = transform.position + new Vector3(0f, 16.5f, 0f);
    //    targetPosition6 = transform.position + new Vector3(0f, 16.5f, 0f);

    //}

    //void Update()
    //{
    //    // move the object towards the target position
    //    transform.position = Vector3.MoveTowards(transform.position, targetPosition, speed * Time.deltaTime);
    //    if (transform.position == targetPosition)
    //    {
    //        transform.position = Vector3.MoveTowards(transform.position, targetPosition2, speed * Time.deltaTime);
    //    }

    //}
    //private Vector3 direction;
    //public double moveRight = .5;
    //public double moveLeft = -.5;
    //public double moveUp = .5;
    //public double moveDown = -.5;

    ////List<double> moves = new List<double>(){ .5, -.5, .5, -.5 };

    //void OnCollisionEnter(Collision col)
    //{
    //    if(col.gameObject.tag == "Wall")
    //    {
    //        chooseDirection();
    //    }
    //}
    //void chooseDirection()
    //{

    //    int randInt = Random.Range(1, 4);

    //    switch (randInt)
    //    {
    //        case 1:
    //            transform.Translate(Vector2.up * 2f * Time.deltaTime);

    //            break;
    //        case 2:
    //            transform.Translate(Vector2.down * -2f * Time.deltaTime);

    //            break;
    //        case 3:
    //            transform.Translate(Vector2.left * 2f * Time.deltaTime);

    //            break;
    //        case 4:
    //            transform.Translate(Vector2.right * -2f * Time.deltaTime);

    //            break;
    //    }

    //}

    //// Start is called before the first frame update
    //void Start()
    //{

    //}

    //// Update is called once per frame
    //void Update()
    //{

    //}
}
